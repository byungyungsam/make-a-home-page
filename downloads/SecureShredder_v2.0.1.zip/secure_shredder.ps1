﻿# Requires -RunAsAdministrator
# SecureShredder v2.0.1
# DoD 5220.22-M 3-Pass Secure File Deletion Tool

$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Clear-Host
Write-Host "==========================================================" -ForegroundColor Red
Write-Host "        SecureShredder v2.0.1 (DoD 5220.22-M)             " -ForegroundColor Red
Write-Host "==========================================================" -ForegroundColor Red
Write-Host "  주의: 이 도구로 삭제된 파일은 어떠한 복구 프로그램으로도"
Write-Host "        복구할 수 없으며 영구적으로 파괴됩니다."
Write-Host "==========================================================" -ForegroundColor Red
Write-Host ""

$filePath = Read-Host "파쇄할 파일 또는 폴더의 전체 경로를 입력하거나 드래그해 넣으세요"
$filePath = $filePath.Trim('"', "'")

if (-not (Test-Path $filePath)) {
    Write-Host "경로가 존재하지 않습니다: $filePath" -ForegroundColor Yellow
    Read-Host "종료하려면 Enter 키를 누르세요..."
    Exit
}

$confirm = Read-Host "정말 영구히 삭제하시겠습니까? (Y/N)"
if ($confirm -ne "Y" -and $confirm -ne "y") {
    Write-Host "취소되었습니다."
    Read-Host "종료하려면 Enter 키를 누르세요..."
    Exit
}

function Shred-File {
    param ([string]$file)
    try {
        $stream = [System.IO.File]::Open($file, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
        $length = $stream.Length
        
        Write-Host "  [*] 1단계: 0으로 덮어쓰는 중... ($file)" -ForegroundColor Gray
        $stream.Position = 0
        $zeroArray = New-Object byte[] 4096
        $bytesWritten = 0
        while ($bytesWritten -lt $length) {
            $toWrite = [math]::min(4096, $length - $bytesWritten)
            $stream.Write($zeroArray, 0, $toWrite)
            $bytesWritten += $toWrite
        }
        $stream.Flush()
        
        Write-Host "  [*] 2단계: 1로 덮어쓰는 중..." -ForegroundColor Gray
        $stream.Position = 0
        $onesArray = New-Object byte[] 4096
        for ($i=0; $i -lt 4096; $i++) { $onesArray[$i] = 0xff }
        $bytesWritten = 0
        while ($bytesWritten -lt $length) {
            $toWrite = [math]::min(4096, $length - $bytesWritten)
            $stream.Write($onesArray, 0, $toWrite)
            $bytesWritten += $toWrite
        }
        $stream.Flush()
        
        Write-Host "  [*] 3단계: 랜덤 값으로 덮어쓰는 중..." -ForegroundColor Gray
        $stream.Position = 0
        $rand = New-Object System.Random
        $randArray = New-Object byte[] 4096
        $bytesWritten = 0
        while ($bytesWritten -lt $length) {
            $rand.NextBytes($randArray)
            $toWrite = [math]::min(4096, $length - $bytesWritten)
            $stream.Write($randArray, 0, $toWrite)
            $bytesWritten += $toWrite
        }
        $stream.Flush()
        $stream.Close()
        
        $parentDir = Split-Path $file -Parent
        $randName = [System.IO.Path]::GetRandomFileName()
        $tempNewPath = Join-Path $parentDir $randName
        Rename-Item -Path $file -NewName $randName -Force
        
        Remove-Item -Path $tempNewPath -Force
        Write-Host "  [+] 파일 영구 파쇄 완료!" -ForegroundColor Green
    } catch {
        Write-Host "  [-] 파쇄 실패: $_" -ForegroundColor Yellow
    }
}

if (Test-Path $filePath -PathType Container) {
    $files = Get-ChildItem -Path $filePath -Recurse -File
    foreach ($f in $files) {
        Shred-File -file $f.FullName
    }
    Remove-Item -Path $filePath -Recurse -Force
    Write-Host "폴더 영구 삭제 완료!" -ForegroundColor Green
} else {
    Shred-File -file $filePath
}

Read-Host "완료되었습니다. 창을 닫으려면 Enter 키를 누르세요..."
