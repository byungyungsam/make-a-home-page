# Get disk space
Write-Output "=== Disk Space ==="
Get-PSDrive -PSProvider FileSystem | Select-Object Name, @{Name="Used(GB)";Expression={[math]::round($_.Used/1GB,2)}}, @{Name="Free(GB)";Expression={[math]::round($_.Free/1GB,2)}}, @{Name="Total(GB)";Expression={[math]::round(($_.Used+$_.Free)/1GB,2)}} | Format-Table -AutoSize

# Get top CPU/Memory processes
Write-Output "=== Top 10 CPU/Memory Processes ==="
Get-Process | Sort-Object CPU -Descending | Select-Object -First 10 -Property Id, ProcessName, CPU, @{Name="WorkingSet(MB)";Expression={[math]::round($_.WorkingSet/1MB,2)}} | Format-Table -AutoSize

# Get detailed info of target processes
Write-Output "=== Detailed Target Processes ==="
$targetPatterns = "Grid|XTor|nat|Smartfile|IMGSF|DataHelper|SSScheduler"
Get-Process | Where-Object {$_.ProcessName -match $targetPatterns} | Select-Object Id, ProcessName, Path | Format-Table -AutoSize

# Check known grid/adware services
Write-Output "=== Known Grid/Adware Services ==="
$servicesToCheck = @("NATService", "SmartfileSrv", "Wondershare", "McAfee", "CDAServer", "stsess")
foreach ($srv in $servicesToCheck) {
    Get-Service -Name *$srv* -ErrorAction SilentlyContinue | Select-Object Name, DisplayName, Status, StartType | Format-Table -AutoSize
}

# Check Uninstall Strings for target programs
Write-Output "=== Uninstall Strings for Target Programs ==="
$unwantedNames = @("NAT Service", "Smartfile", "McAfee Security Scan", "Wondershare", "HitPaw", "Gala Node", "Gala Launcher", "Common Desktop Agent", "HGrid", "XTor")
Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*, HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue | 
    Where-Object {
        $displayName = $_.DisplayName
        $match = $false
        foreach ($name in $unwantedNames) {
            if ($displayName -and $displayName -like "*$name*") { $match = $true }
        }
        $match
    } | Select-Object DisplayName, UninstallString | Format-Table -AutoSize

# Check known grid/adware files/directories
Write-Output "=== Checking Known Adware/Grid Locations ==="
$pathsToCheck = @(
    "C:\Program Files (x86)\NAT Service",
    "C:\Program Files (x86)\Smartfile",
    "C:\Program Files\Common Files\Common Desktop Agent",
    "C:\Program Files (x86)\Common Files\Wondershare",
    "C:\Program Files\Gala\GalaNode",
    "C:\Program Files (x86)\McAfee Security Scan Plus"
)
foreach ($path in $pathsToCheck) {
    if (Test-Path $path) {
        Write-Output "Found directory: $path"
    }
}

# Check Temp folder sizes
Write-Output "=== Temporary Directories Sizes ==="
$tempFolders = @(
    "C:\Windows\Temp",
    "C:\Windows\Prefetch",
    "$env:LOCALAPPDATA\Temp"
)
foreach ($folder in $tempFolders) {
    if (Test-Path $folder) {
        try {
            $files = Get-ChildItem -Path $folder -Recurse -File -ErrorAction SilentlyContinue
            $size = ($files | Measure-Object -Property Length -Sum).Sum
            $sizeMB = [math]::round($size / 1MB, 2)
            $count = $files.Count
            Write-Output "$folder : $sizeMB MB ($count files)"
        } catch {
            Write-Output "$folder : Failed to calculate size"
        }
    } else {
        Write-Output "$folder : Directory not found"
    }
}
