# 1. Stop and Disable NATService
Write-Output "Stopping and disabling NATService..."
$natService = Get-Service -Name "NATService" -ErrorAction SilentlyContinue
if ($natService) {
    if ($natService.Status -eq 'Running') {
        Stop-Service -Name "NATService" -Force -ErrorAction SilentlyContinue
        Write-Output "NATService stopped."
    }
    Set-Service -Name "NATService" -StartupType Disabled -ErrorAction SilentlyContinue
    Write-Output "NATService disabled."
} else {
    Write-Output "NATService not found."
}

# 2. Terminate target processes
$processesToKill = @("natsvc", "HGridEngine", "HGridStream", "XTorEngine", "SmartfileLauncher", "SSScheduler")
Write-Output "Terminating unwanted processes..."
foreach ($procName in $processesToKill) {
    $procs = Get-Process -Name $procName -ErrorAction SilentlyContinue
    if ($procs) {
        Stop-Process -Name $procName -Force -ErrorAction SilentlyContinue
        Write-Output "Terminated process: $procName"
    } else {
        Write-Output "Process not running: $procName"
    }
}

# 3. Clean temporary files
Write-Output "Cleaning temporary directories..."
$tempFolders = @(
    "C:\Windows\Temp",
    "C:\Windows\Prefetch",
    "$env:LOCALAPPDATA\Temp"
)

foreach ($folder in $tempFolders) {
    if (Test-Path $folder) {
        Write-Output "Cleaning: $folder"
        try {
            # Delete files and subfolders
            Get-ChildItem -Path $folder -Recurse -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
            Write-Output "Finished cleaning $folder (locked files might remain)."
        } catch {
            Write-Output "Failed to fully clean $folder"
        }
    }
}

Write-Output "Cleanup execution completed."
