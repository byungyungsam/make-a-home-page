/**
 * Galaga Modern - Core Game Engine
 */

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreElement = document.getElementById('score');
const finalScoreElement = document.getElementById('final-score');
const stageValElement = document.getElementById('stage-val');
const overlay = document.getElementById('overlay');
const bestPlayerInfo = document.getElementById('best-player-info');
const highScoreForm = document.getElementById('new-high-score-form');
const playerNameInput = document.getElementById('player-name-input');
const gameOverOverlay = document.getElementById('game-over');
const startBtn = document.getElementById('start-btn');
const restartBtn = document.getElementById('restart-btn');

// Game constants
const CANVAS_WIDTH = 600;
const CANVAS_HEIGHT = 800;

// User Adjustable Settings (Defaults)
let userPlayerSpeed = 7;
let userEnemyDescentSpeed = 1.5;
let bombFrequencyLevel = 5; // 1-5

// Bullet constants
const BULLET_SPEED = -10;
const ENEMY_BULLET_SPEED = 5;

let enemyDirection = 1;
let enemyMoveDownRequested = false;

canvas.width = CANVAS_WIDTH;
canvas.height = CANVAS_HEIGHT;

// Game State
let gameState = 'START'; // START, PLAYING, GAMEOVER, WAVE_CLEAR
let score = 0;
let lives = 3;
let stage = 1;
let isInvulnerable = false;
let invulnerabilityTimeout = null;
let keys = {};
let gameLoopId;
let isLoopRunning = false;

// Entities
let player;
let bullets = [];
let enemyBullets = [];
let enemies = [];
let particles = [];
let stars = [];

// Assets
const playerImg = new Image();
playerImg.src = 'assets/player.png';
const enemyImg = new Image();
enemyImg.src = 'assets/enemy.png';

/**
 * High Score System (Top 3)
 */
function getHighScores() {
    const saved = localStorage.getItem('galaga_best_list');
    return saved ? JSON.parse(saved) : [];
}

function saveHighScore(name, score, level) {
    let scores = getHighScores();
    scores.push({ name, score, level });
    // Sort descending
    scores.sort((a, b) => b.score - a.score);
    // Keep top 3
    scores = scores.slice(0, 3);
    localStorage.setItem('galaga_best_list', JSON.stringify(scores));
    updateHighScoreDisplay();
}

function updateHighScoreDisplay() {
    const scores = getHighScores();
    if (bestPlayerInfo) {
        if (scores.length === 0) {
            bestPlayerInfo.innerHTML = '<div>--: 0 (Lv.0)</div>';
        } else {
            bestPlayerInfo.innerHTML = scores.map((s, idx) =>
                `<div class="score-entry"><span>${idx + 1}. ${s.name}</span> <span>${s.score} (Lv.${s.level})</span></div>`
            ).join('');
        }
    }
}

// Initial board update
updateHighScoreDisplay();

/**
 * Game Classes
 */
class Player {
    constructor() {
        this.width = 60;
        this.height = 60;
        this.x = CANVAS_WIDTH / 2 - this.width / 2;
        this.y = CANVAS_HEIGHT - 100;
        this.color = '#00f3ff';
        this.canShoot = true;
        this.shootCooldown = 250;
    }

    draw() {
        ctx.save();
        ctx.translate(this.x + this.width / 2, this.y + this.height / 2);

        // Ship Body
        ctx.fillStyle = '#00f3ff';
        ctx.shadowBlur = 15;
        ctx.shadowColor = '#00f3ff';
        ctx.beginPath();
        ctx.moveTo(0, -this.height / 2);
        ctx.lineTo(this.width / 2, this.height / 2);
        ctx.lineTo(0, this.height / 3);
        ctx.lineTo(-this.width / 2, this.height / 2);
        ctx.closePath();
        ctx.fill();

        // Cockpit
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(0, -5, 5, 0, Math.PI * 2);
        ctx.fill();

        // Engine glow
        ctx.fillStyle = '#fff';
        ctx.globalAlpha = 0.5 + Math.random() * 0.5;
        ctx.beginPath();
        ctx.moveTo(-10, this.height / 2);
        ctx.lineTo(10, this.height / 2);
        ctx.lineTo(0, this.height / 2 + 15);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
    }

    update() {
        if (keys['ArrowLeft'] && this.x > 0) {
            this.x -= userPlayerSpeed;
        }
        if (keys['ArrowRight'] && this.x + this.width < CANVAS_WIDTH) {
            this.x += userPlayerSpeed;
        }
        if (keys[' '] && this.canShoot) {
            this.shoot();
        }
    }

    shoot() {
        bullets.push(new Bullet(this.x + this.width / 2 - 2, this.y, BULLET_SPEED, '#00f3ff'));
        playShootSound();
        this.canShoot = false;
        setTimeout(() => this.canShoot = true, this.shootCooldown);
    }

    respawn() {
        this.x = CANVAS_WIDTH / 2 - this.width / 2;
        this.y = CANVAS_HEIGHT - 100;

        // Clear old timeout if exists
        if (invulnerabilityTimeout) clearTimeout(invulnerabilityTimeout);

        isInvulnerable = true;
        invulnerabilityTimeout = setTimeout(() => {
            isInvulnerable = false;
            invulnerabilityTimeout = null;
        }, 2000);
    }
}

class Bullet {
    constructor(x, y, speed, color) {
        this.x = x;
        this.y = y;
        this.width = 4;
        this.height = 15;
        this.speed = speed;
        this.color = color;
    }

    draw() {
        ctx.fillStyle = this.color;
        ctx.shadowBlur = 10;
        ctx.shadowColor = this.color;
        ctx.fillRect(this.x, this.y, this.width, this.height);
        ctx.shadowBlur = 0;
    }

    update() {
        this.y += this.speed;
    }
}

class Enemy {
    constructor(x, y, type) {
        this.x = x;
        this.y = y;
        this.width = 45;
        this.height = 45;
        this.type = type;
        this.direction = 1;
        this.moveX = 30;
        this.currentMoveX = 0;
    }

    draw() {
        ctx.save();
        ctx.translate(this.x + this.width / 2, this.y + this.height / 2);

        // Enemy Body
        ctx.fillStyle = '#bc00ff';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#bc00ff';
        ctx.beginPath();
        ctx.moveTo(0, this.height / 2);
        ctx.lineTo(this.width / 2, -this.height / 2);
        ctx.lineTo(this.width / 4, 0);
        ctx.lineTo(-this.width / 4, 0);
        ctx.lineTo(-this.width / 2, -this.height / 2);
        ctx.closePath();
        ctx.fill();

        // Eyes
        ctx.fillStyle = '#ff0055';
        ctx.beginPath();
        ctx.arc(-10, 5, 4, 0, Math.PI * 2);
        ctx.arc(10, 5, 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
    }

    update() {
        this.x += userEnemyDescentSpeed * enemyDirection;
        if (enemyMoveDownRequested) {
            this.y += 10;
        }

        // Difficulty based shooting (Level 5 = ~0.005 prob)
        const baseProb = 0.001;
        const shootProb = baseProb * bombFrequencyLevel;
        if (Math.random() < shootProb) {
            this.shoot();
        }
    }

    shoot() {
        enemyBullets.push(new Bullet(this.x + this.width / 2, this.y + this.height, ENEMY_BULLET_SPEED, '#ff0055'));
    }
}

class Particle {
    constructor(x, y, color) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.size = Math.random() * 3 + 1;
        this.speedX = (Math.random() - 0.5) * 8;
        this.speedY = (Math.random() - 0.5) * 8;
        this.life = 1.0;
        this.decay = Math.random() * 0.02 + 0.02;
    }

    draw() {
        ctx.globalAlpha = this.life;
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
    }

    update() {
        this.x += this.speedX;
        this.y += this.speedY;
        this.life -= this.decay;
    }
}

class Star {
    constructor() {
        this.x = Math.random() * CANVAS_WIDTH;
        this.y = Math.random() * CANVAS_HEIGHT;
        this.size = Math.random() * 2;
        this.speed = Math.random() * 2 + 0.5;
    }

    update() {
        this.y += this.speed;
        if (this.y > CANVAS_HEIGHT) {
            this.y = 0;
            this.x = Math.random() * CANVAS_WIDTH;
        }
    }

    draw() {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.fillRect(this.x, this.y, this.size, this.size);
    }
}

/**
 * Sound Engine
 */
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

function playShootSound() {
    if (audioCtx.state === 'suspended') {
        audioCtx.resume();
    }
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.type = 'square';
    oscillator.frequency.setValueAtTime(400, audioCtx.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(100, audioCtx.currentTime + 0.1);

    gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);

    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    oscillator.start();
    oscillator.stop(audioCtx.currentTime + 0.1);
}

function playExplosionSound() {
    if (audioCtx.state === 'suspended') {
        audioCtx.resume();
    }
    const noiseBuffer = audioCtx.createBuffer(1, audioCtx.sampleRate * 0.2, audioCtx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < noiseBuffer.length; i++) {
        output[i] = Math.random() * 2 - 1;
    }

    const noise = audioCtx.createBufferSource();
    noise.buffer = noiseBuffer;

    const filter = audioCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(500, audioCtx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(10, audioCtx.currentTime + 0.2);

    const gainNode = audioCtx.createGain();
    gainNode.gain.setValueAtTime(0.2, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);

    noise.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    noise.start();
}

/**
 * Game Functions
 */
function initStars() {
    stars = [];
    for (let i = 0; i < 150; i++) {
        stars.push(new Star());
    }
}

function updateLivesUI() {
    const container = document.getElementById('lives-container');
    if (!container) return;
    container.innerHTML = '';
    for (let i = 0; i < lives; i++) {
        const life = document.createElement('div');
        life.className = 'life-icon';
        container.appendChild(life);
    }
}

function spawnWave() {
    enemies = [];
    enemyBullets = [];

    // Stage Reward Logic
    if (stage === 4) {
        lives++;
        updateLivesUI();
        console.log('%c[보상] 스테이지 4 도달 - 생명 1개 추가!', 'color: #00f3ff; font-weight: bold');
    } else if (stage > 4 && (stage - 4) % 5 === 0) {
        lives++;
        updateLivesUI();
        console.log(`%c[보상] 스테이지 ${stage} 도달 - 생명 1개 추가!`, 'color: #00f3ff; font-weight: bold');
    }

    if (stageValElement) stageValElement.textContent = stage;

    const rows = 3 + Math.min(stage, 3);
    const cols = 8;
    const spacing = 60;
    const startX = (CANVAS_WIDTH - (cols - 1) * spacing - 45) / 2;
    const startY = 80;

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            enemies.push(new Enemy(startX + c * spacing, startY + r * spacing, r));
        }
    }
}

function createExplosion(x, y, color) {
    for (let i = 0; i < 15; i++) {
        particles.push(new Particle(x, y, color));
    }
}

function checkCollisions() {
    // Player bullets vs Enemies
    for (let i = bullets.length - 1; i >= 0; i--) {
        const b = bullets[i];
        for (let j = enemies.length - 1; j >= 0; j--) {
            const e = enemies[j];
            if (b.x < e.x + e.width &&
                b.x + b.width > e.x &&
                b.y < e.y + e.height &&
                b.y + b.height > e.y) {

                // Hit!
                playExplosionSound();
                createExplosion(e.x + e.width / 2, e.y + e.height / 2, '#bc00ff');
                enemies.splice(j, 1);
                bullets.splice(i, 1);
                score += 100;
                scoreElement.textContent = score.toString().padStart(5, '0');
                break;
            }
        }
    }

    // Enemy bullets vs Player
    if (player && gameState === 'PLAYING') {
        for (let i = enemyBullets.length - 1; i >= 0; i--) {
            const b = enemyBullets[i];
            if (b.x < player.x + player.width &&
                b.x + b.width > player.x &&
                b.y < player.y + player.height &&
                b.y + b.height > player.y) {

                console.log(`%c[COLLISION] Enemy bullet at (${b.x.toFixed(0)}, ${b.y.toFixed(0)})`, 'color: #ff0055');
                handlePlayerHit();
                // Bullet disappears even if invulnerable if it hit the player
                enemyBullets.splice(i, 1);
                break;
            }
        }
    }

    // Enemies vs Player
    if (!isInvulnerable && player && gameState === 'PLAYING') {
        for (const e of enemies) {
            if (e.x < player.x + player.width &&
                e.x + e.width > player.x &&
                e.y < player.y + player.height &&
                e.y + e.height > player.y) {

                console.log(`%c[COLLISION] Enemy crash at (${e.x.toFixed(0)}, ${e.y.toFixed(0)})`, 'color: #ff0055');
                handlePlayerHit();
                break;
            }
        }
    }
}

function handlePlayerHit() {
    if (isInvulnerable || gameState !== 'PLAYING') {
        if (isInvulnerable) console.log('%c[무시] 타격 무시 - 무적 상태', 'color: #bc00ff');
        return;
    }

    lives--;
    updateLivesUI();
    console.log(`%c[피격] 타격 발생! 잔여 생명: ${lives}`, 'color: #ff0055; font-weight: bold');

    createExplosion(player.x + player.width / 2, player.y + player.height / 2, '#00f3ff');

    if (lives <= 0) {
        gameOver();
    } else {
        player.respawn();
    }
}

function update() {
    if (gameState !== 'PLAYING') return;

    player.update();

    stars.forEach(s => s.update());

    // Backwards loop for safe splicing
    for (let i = bullets.length - 1; i >= 0; i--) {
        bullets[i].update();
        if (bullets[i].y < 0) bullets.splice(i, 1);
    }

    for (let i = enemyBullets.length - 1; i >= 0; i--) {
        enemyBullets[i].update();
        if (enemyBullets[i].y > CANVAS_HEIGHT) enemyBullets.splice(i, 1);
    }

    const hitsLeft = enemies.some(e => e.x <= 10);
    const hitsRight = enemies.some(e => e.x + e.width >= CANVAS_WIDTH - 10);

    if (hitsLeft && enemyDirection < 0) {
        enemyDirection = 1;
        enemyMoveDownRequested = true;
    } else if (hitsRight && enemyDirection > 0) {
        enemyDirection = -1;
        enemyMoveDownRequested = true;
    }

    enemies.forEach(e => e.update());
    enemyMoveDownRequested = false;

    particles.forEach((p, i) => {
        p.update();
        if (p.life <= 0) particles.splice(i, 1);
    });

    // Clear wave logic
    if (enemies.length === 0 && gameState === 'PLAYING') {
        gameState = 'WAVE_CLEAR';
        setTimeout(() => {
            if (gameState === 'WAVE_CLEAR') {
                stage++;
                spawnWave();
                gameState = 'PLAYING';
            }
        }, 1500);
        return; // Skip collisions in WAVE_CLEAR state
    }

    checkCollisions();
}

function draw() {
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Background stars
    stars.forEach(s => s.draw());

    if (gameState === 'START') {
        // Draw a static ship on the start screen
        if (!player) player = new Player();
        player.draw();
    }

    if (gameState === 'PLAYING' || gameState === 'WAVE_CLEAR') {
        if (!isInvulnerable || Math.floor(Date.now() / 100) % 2 === 0) {
            if (player) player.draw();
        }
        enemies.forEach(e => e.draw());
        bullets.forEach(b => b.draw());
        enemyBullets.forEach(b => b.draw());
        particles.forEach(p => p.draw());
    }
}

function gameLoop() {
    try {
        if (gameState === 'PLAYING' || gameState === 'WAVE_CLEAR' || gameState === 'START') {
            update();
            draw();
        }
    } catch (error) {
        console.error('%c[오류] 게임 루프 중단:', 'color: #ff0055; font-weight: bold', error);
        isLoopRunning = false;
        return; // Stop the loop on critical error
    }
    gameLoopId = requestAnimationFrame(gameLoop);
}

function startGame() {
    // Prevent button focus issues
    if (document.activeElement) {
        document.activeElement.blur();
    }

    console.log('%c[엔진] 작전 개시...', 'color: #00f3ff; font-weight: bold');

    // High Score Saving Logic if name form is visible
    if (!highScoreForm.classList.contains('hidden')) {
        const newName = playerNameInput.value.trim();
        if (newName) {
            saveHighScore(newName, score, bombFrequencyLevel);
        }
        highScoreForm.classList.add('hidden');
        playerNameInput.value = '';
    }

    // Reset State
    score = 0;
    lives = 3;
    stage = 1;
    bullets = [];
    enemyBullets = [];
    enemies = [];
    particles = [];

    if (scoreElement) scoreElement.textContent = '00000';
    updateLivesUI();
    player = new Player();
    initStars();
    spawnWave();

    // UI Toggle
    overlay.classList.remove('visible');
    overlay.classList.add('hidden');
    gameOverOverlay.classList.remove('visible');
    gameOverOverlay.classList.add('hidden');

    // Invulnerability
    if (invulnerabilityTimeout) clearTimeout(invulnerabilityTimeout);
    isInvulnerable = true;
    console.log('%c[상태] 무적 모드 활성화', 'color: #bc00ff');
    invulnerabilityTimeout = setTimeout(() => {
        isInvulnerable = false;
        invulnerabilityTimeout = null;
        console.log('%c[상태] 무적 모드 해제', 'color: #ff0055');
    }, 2000);

    gameState = 'PLAYING';

    // Singleton Loop Start
    if (!isLoopRunning) {
        isLoopRunning = true;
        gameLoop();
    }

    // New game starts, stage display is reset
    if (stageValElement) stageValElement.textContent = stage;
}

function returnToStart() {
    // Save name if form is visible
    if (!highScoreForm.classList.contains('hidden')) {
        const newName = playerNameInput.value.trim();
        if (newName) {
            saveHighScore(newName, score, bombFrequencyLevel);
        }
        highScoreForm.classList.add('hidden');
        playerNameInput.value = '';
    }

    gameState = 'START';
    overlay.classList.remove('hidden');
    overlay.classList.add('visible');
    gameOverOverlay.classList.remove('visible');
    gameOverOverlay.classList.add('hidden');

    // Refresh leaderboard
    updateHighScoreDisplay();

    console.log('%c[상태] 시작 화면으로 전환', 'color: #00f3ff');
}

function gameOver() {
    if (gameState === 'GAMEOVER') return;
    console.log('%c[상태] 작전 종료 (게임 오버). 잔여 생명:', 'color: #ff0055', lives);
    gameState = 'GAMEOVER';
    createExplosion(player.x + player.width / 2, player.y + player.height / 2, '#00f3ff');

    // High Score Check
    const scores = getHighScores();
    const isTop3 = scores.length < 3 || score > scores[scores.length - 1].score;

    if (isTop3) {
        highScoreForm.classList.remove('hidden');
        // Focus the name input immediately to alert the user
        setTimeout(() => playerNameInput.focus(), 100);
    } else {
        highScoreForm.classList.add('hidden');
    }

    setTimeout(() => {
        if (gameState === 'GAMEOVER') {
            gameOverOverlay.classList.remove('hidden');
            gameOverOverlay.classList.add('visible');
            if (finalScoreElement) finalScoreElement.textContent = score;
        }
    }, 1000);
}

/**
 * Event Listeners
 */
window.addEventListener('keydown', e => {
    keys[e.key] = true;
    // Prevent accidental scroll or button click with Space
    if (e.key === ' ' && (gameState === 'PLAYING' || gameState === 'GAMEOVER')) {
        e.preventDefault();
    }
});
window.addEventListener('keyup', e => keys[e.key] = false);

startBtn.addEventListener('click', startGame);
restartBtn.addEventListener('click', startGame);

// Initialize background stars even on start screen
initStars();
gameLoop();

/**
 * Settings Listeners
 */
const playerSpeedSlider = document.getElementById('player-speed-slider');
const enemySpeedSlider = document.getElementById('enemy-speed-slider');
const playerSpeedVal = document.getElementById('player-speed-val');
const enemySpeedVal = document.getElementById('enemy-speed-val');
const diffBtns = document.querySelectorAll('.diff-btn');

playerNameInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        returnToStart();
    }
});

playerSpeedSlider.addEventListener('input', (e) => {
    userPlayerSpeed = parseInt(e.target.value);
    playerSpeedVal.textContent = userPlayerSpeed;
    console.log(`[SETTINGS] Player Speed: ${userPlayerSpeed}`);
});

enemySpeedSlider.addEventListener('input', (e) => {
    userEnemyDescentSpeed = parseFloat(e.target.value);
    enemySpeedVal.textContent = userEnemyDescentSpeed.toFixed(1);
    console.log(`[SETTINGS] Enemy Speed: ${userEnemyDescentSpeed}`);
});

diffBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        diffBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        bombFrequencyLevel = parseInt(btn.dataset.level);
        console.log(`[SETTINGS] Bomb Frequency Level: ${bombFrequencyLevel}`);
    });
});
