$WshShell = New-Object -ComObject WScript.Shell
$DesktopPath = [System.Environment]::GetFolderPath('Desktop')
$Shortcut = $WshShell.CreateShortcut("$DesktopPath\Galaga Modern.lnk")
$Shortcut.TargetPath = "d:\antigravity\galaga-game\index.html"
$Shortcut.Description = "Play Galaga Modern"
$Shortcut.Save()
Write-Host "Shortcut created on Desktop at $DesktopPath"
