﻿# Requires -RunAsAdministrator
# Windows PC Optimizer (통합 PC 최적화 도구)
# 용도: 하드 디스크 용량 정리 및 불필요한 그리드/시작프로그램 정리로 PC 속도 향상

$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# ==============================================================================
# 0. 관리자 권한 자동 상승
# ==============================================================================
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "관리자 권한이 필요합니다. 관리자 권한으로 스크립트를 다시 실행합니다..." -ForegroundColor Yellow
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    Exit
}

# ==============================================================================
# Helper 함수 정의
# ==============================================================================
# 폴더 정리 및 정리된 용량 측정 함수
function Clean-Folder {
    param (
        [string]$Path
    )
    if (-not (Test-Path $Path)) {
        Write-Host "  [-] 존재하지 않음: $Path" -ForegroundColor DarkGray
        return 0
    }
    
    Write-Host "  [*] 정리 중: $Path ... " -NoNewline
    try {
        $files = Get-ChildItem -Path $Path -Recurse -File -ErrorAction SilentlyContinue
        $totalSize = ($files | Measure-Object -Property Length -Sum).Sum
        if ($null -eq $totalSize) { $totalSize = 0 }
        
        # 파일 및 하위 폴더 삭제
        Get-ChildItem -Path $Path -ErrorAction SilentlyContinue | ForEach-Object {
            Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
        
        $sizeMB = [math]::round($totalSize / 1MB, 2)
        Write-Host "완료 ($sizeMB MB 정리됨)" -ForegroundColor Green
        return $totalSize
    } catch {
        Write-Host "일부 파일 삭제 실패 (사용 중인 파일 제외됨)" -ForegroundColor Yellow
        return 0
    }
}

# 휴지통 용량 확인 함수
function Get-RecycleBinSize {
    try {
        $shell = New-Object -ComObject Shell.Application
        $recycleBin = $shell.Namespace(0x0a) # 0x0a = Recycle Bin
        $size = 0
        foreach ($item in $recycleBin.Items()) {
            $size += $item.Size
        }
        return $size
    } catch {
        return 0
    }
}

# ==============================================================================
# 메인 화면 출력
# ==============================================================================
Clear-Host
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "          Windows 통합 PC 최적화 도구 (Universal)          " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  이 프로그램은 다음 두 단계를 순차적으로 진행합니다:"
Write-Host "  1단계: 하드 디스크 용량 늘리기 (임시 파일, 캐시, 휴지통 정리)"
Write-Host "  2단계: PC 처리 속도 향상 (그리드 프로그램 차단 및 서비스 정리)"
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host ""

# C드라이브 디스크 용량 확인
$cDrive = Get-PSDrive -Name C -ErrorAction SilentlyContinue
if ($cDrive) {
    $freeGB = [math]::round($cDrive.Free / 1GB, 2)
    $totalGB = [math]::round(($cDrive.Used + $cDrive.Free) / 1GB, 2)
    Write-Host "[현재 디스크 상태] C드라이브 여유 공간: $freeGB GB / 전체 용량: $totalGB GB" -ForegroundColor White
}
Write-Host ""

# ==============================================================================
# 1단계: 하드 용량 늘리기 (Disk Space Optimization)
# ==============================================================================
Write-Host "[1단계] 하드 용량 늘리기 작업을 시작합니다..." -ForegroundColor Cyan
$totalBytesSaved = 0

$tempFolders = @(
    "C:\Windows\Temp",
    "C:\Windows\Prefetch",
    "$env:LOCALAPPDATA\Temp"
)

# 임시 폴더들 정리
foreach ($folder in $tempFolders) {
    $totalBytesSaved += Clean-Folder -Path $folder
}

# Windows 업데이트 다운로드 캐시 정리
$winUpdateCache = "C:\Windows\SoftwareDistribution\Download"
$totalBytesSaved += Clean-Folder -Path $winUpdateCache

# 휴지통 정리
Write-Host "  [*] 휴지통 비우기 진행 중... " -NoNewline
$binSize = Get-RecycleBinSize
try {
    Clear-RecycleBin -Force -ErrorAction SilentlyContinue
    $binSizeMB = [math]::round($binSize / 1MB, 2)
    Write-Host "완료 ($binSizeMB MB 정리됨)" -ForegroundColor Green
    $totalBytesSaved += $binSize
} catch {
    Write-Host "건너뜀 (이미 비어있거나 권한 부족)" -ForegroundColor DarkGray
}

$totalSavedMB = [math]::round($totalBytesSaved / 1MB, 2)
Write-Host ">> 1단계 완료: 총 $totalSavedMB MB의 용량을 확보했습니다." -ForegroundColor Green
Write-Host ""

# ==============================================================================
# 2단계: PC 처리 속도 향상 (Speed Optimization & Grid Cleanup)
# ==============================================================================
Write-Host "[2단계] 불필요한 그리드 서비스 및 프로세스 정리를 시작합니다..." -ForegroundColor Cyan

# 2.1 프로세스 종료
$processesToKill = @(
    "natsvc", "HGridEngine", "HGridStream", "XTorEngine", 
    "SmartfileLauncher", "SSScheduler", "QuickDownload", "ExpressService"
)

Write-Host "  [*] 불필요한/그리드 백그라운드 프로세스 종료 중..."
foreach ($procName in $processesToKill) {
    $procs = Get-Process -Name $procName -ErrorAction SilentlyContinue
    if ($procs) {
        Stop-Process -Name $procName -Force -ErrorAction SilentlyContinue
        Write-Host "      - 종료된 프로세스: $procName" -ForegroundColor Yellow
    }
}

# 2.2 서비스 중지 및 사용 안 함 설정
$servicesToStop = @(
    "NATService", "SmartfileSrv", "Wondershare", "McAfee", 
    "CDAServer", "stsess", "quickdownloadsvc"
)

Write-Host "  [*] 그리드 및 광고성 서비스 중지 및 차단 중..."
foreach ($srvName in $servicesToStop) {
    # 와일드카드로 매칭되는 서비스 검색
    $services = Get-Service -Name "*$srvName*" -ErrorAction SilentlyContinue
    foreach ($srv in $services) {
        if ($srv.Status -eq 'Running') {
            Stop-Service -Name $srv.Name -Force -ErrorAction SilentlyContinue
            Write-Host "      - 서비스 중지됨: $($srv.DisplayName)" -ForegroundColor Yellow
        }
        Set-Service -Name $srv.Name -StartupType Disabled -ErrorAction SilentlyContinue
        Write-Host "      - 서비스 차단됨(사용 안 함): $($srv.DisplayName)" -ForegroundColor DarkYellow
    }
}

# 2.3 레지스트리 시작프로그램 정리 (그리드/광고성 프로그램 전용)
Write-Host "  [*] 불필요한 시작프로그램 레지스트리 정리 중..."
$runPaths = @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Run",
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
)
$unwantedKeywords = @("NATService", "Smartfile", "HGrid", "XTor", "Wondershare", "McAfee", "HitPaw", "GalaNode")

foreach ($runPath in $runPaths) {
    if (Test-Path $runPath) {
        $properties = Get-ItemProperty -Path $runPath -ErrorAction SilentlyContinue
        foreach ($propName in $properties.PSObject.Properties.Name) {
            # 시스템 기본 속성 제외
            if ($propName -match "^(PSPath|PSParentPath|PSChildName|PSDrive|PSProvider|PSIsContainer)$") { continue }
            
            $val = $properties.$propName
            $shouldRemove = $false
            foreach ($keyword in $unwantedKeywords) {
                if ($propName -like "*$keyword*" -or $val -like "*$keyword*") {
                    $shouldRemove = $true
                    break
                }
            }
            if ($shouldRemove) {
                Remove-ItemProperty -Path $runPath -Name $propName -Force -ErrorAction SilentlyContinue
                Write-Host "      - 레지스트리 시작프로그램 제거됨: $propName ($runPath)" -ForegroundColor Yellow
            }
        }
    }
}

Write-Host ">> 2단계 완료: 불필요한 그리드 서비스 및 프로세스를 성공적으로 정지 및 차단했습니다." -ForegroundColor Green
Write-Host ""

# ==============================================================================
# 3. 추가 점검 안내 (사용자를 위한 교육용 정보 제공)
# ==============================================================================
Write-Host "========================= 추가 추천 조치 =========================" -ForegroundColor Cyan
Write-Host "  1. 제어판의 [프로그램 추가/제거]에서 아래 프로그램이 있다면 직접 삭제해 주세요:"
Write-Host "     - NAT Service, Smartfile, Wondershare, McAfee Security Scan, HitPaw, Gala Launcher"
Write-Host "  2. 시작프로그램 전체 목록을 직접 확인하고 불필요한 앱을 끄려면:"
Write-Host "     - [Ctrl + Shift + Esc]를 눌러 작업 관리자를 엽니다."
Write-Host "     - '시작 앱'(또는 '시작프로그램') 탭에서 필요 없는 프로그램(예: 메신저 자동시작 등)을 우클릭하여 '사용 안 함'으로 설정하세요."
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""

# 최종 결과 비교
$driveAfter = Get-PSDrive -Name C -ErrorAction SilentlyContinue
if ($driveAfter) {
    $afterFreeGB = [math]::round($driveAfter.Free / 1GB, 2)
    Write-Host "[최적화 완료] C드라이브 여유 공간: $afterFreeGB GB (총 $totalSavedMB MB 정리됨)" -ForegroundColor Green
}
Write-Host ""
Write-Host "모든 최적화 작업이 끝났습니다. 창을 닫으려면 Enter 키를 누르세요..."
Read-Host
