🚀 Galaga Modern - 프리미엄 우주 슈팅 게임 (Premium Space Shooter)
============================================================

[KOREAN - 한글 설명서]
------------------------------------------------------------
사용자님의 브라우저에서 바로 즐길 수 있는 현대적 감각의 갤러그 게임입니다.

■ 실행 방법
  1. index.html 파일을 마우스 오른쪽 버튼으로 클릭합니다.
  2. '연결 프로그램' -> 'Google Chrome' 또는 'Microsoft Edge'를 선택하여 실행합니다.
  (최신 웨일 브라우저도 지원합니다.)

■ 조작 방법
  - 이동: 키보드 방향키 (←, →)
  - 발사: 스페이스바 (SPACE)
  - 확인/입력: 엔터 키 (ENTER)

■ 게임 특징
  - 스테이지 4 도달 시 생명 +1, 이후 5스테이지마다 추가 보너스!
  - 상위 3위까지의 명예의 전당 기록 시스템.
  - 슈터 속도 및 난이도(미사일 투하량) 자유 조절 가능.

------------------------------------------------------------

[ENGLISH - English Instructions]
------------------------------------------------------------
A modern adaptation of the classic Galaga, playable directly in your browser.

■ How to Play
  1. Right-click the 'index.html' file.
  2. Select 'Open with' -> 'Google Chrome' or 'Microsoft Edge'.
  (Works on most modern web browsers.)

■ Controls
  - Move: Arrow keys (Left, Right)
  - Fire: Spacebar (SPACE)
  - Confirm/Submit: Enter Key (ENTER)

■ Features
  - Bonus Life at Stage 4 and every 5 stages after!
  - Hall of Fame records for top 3 players.
  - Adjustable player speed and difficulty (missile frequency).

------------------------------------------------------------
제공: Antigravity AI Engine
Development: Antigravity AI Engine
